<?php

namespace seraph_accel\JSMin;

class UnterminatedRegExpException extends \Exception {
}
