window.seraph_accel={};
